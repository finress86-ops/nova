package com.example.nova

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Msg(val text: String, val mine: Boolean)
class Chat(val name: String, val emoji: String, first: String) {
    val msgs = mutableStateListOf(Msg(first, false))
}
data class Gift(val emoji: String, val name: String, val price: Int, val limit: Int? = null)
class Plugin(val name: String, val desc: String, val fn: (String) -> String)

val Accent = Color(0xFF2AABEE)
val LocalDark = compositionLocalOf { true }

val palette = listOf(Color(0xFF2AABEE), Color(0xFFFF5252), Color(0xFFFFB300), Color(0xFF66BB6A), Color(0xFFAB47BC), Color(0xFFFF6EC7))
val frames = listOf(
    Brush.sweepGradient(listOf(Color.Cyan, Color.Magenta, Color.Cyan)),
    Brush.sweepGradient(listOf(Color(0xFFFFD54F), Color(0xFFFF6F00), Color(0xFFFFD54F))),
    Brush.sweepGradient(listOf(Color(0xFF69F0AE), Color(0xFF00B0FF), Color(0xFF69F0AE))),
    Brush.linearGradient(listOf(Color.White, Color.Gray))
)
val banners = listOf(
    Brush.linearGradient(listOf(Color(0xFF2AABEE), Color(0xFF7C4DFF))),
    Brush.linearGradient(listOf(Color(0xFFFF8A65), Color(0xFFD81B60))),
    Brush.linearGradient(listOf(Color(0xFF00C6A7), Color(0xFF1E4D92))),
    Brush.linearGradient(listOf(Color(0xFF232526), Color(0xFF414345)))
)
val gifts = listOf(
    Gift("🌹", "Роза", 5), Gift("🧸", "Мишка", 15), Gift("🎂", "Торт", 30), Gift("💎", "Алмаз", 100),
    Gift("🐉", "Дракон", 500, 10), Gift("🚀", "Ракета", 1000, 5)
)
val plugins = listOf(
    Plugin("Блёстки", "Добавляет ✨ к сообщениям") { "$it ✨" },
    Plugin("КАПС", "Пишет всё заглавными") { it.uppercase() },
    Plugin("Эхо", "Дублирует последнее слово") { t -> t + " " + t.substringAfterLast(' ') }
)

class AppState {
    var dark by mutableStateOf(true)
    var nick by mutableStateOf("Nova User")
    var bio by mutableStateOf("Привет! Я в Nova")
    var nickColor by mutableStateOf(palette[0])
    var frame by mutableIntStateOf(0)
    var banner by mutableIntStateOf(0)
    var coins by mutableIntStateOf(50)
    val myGifts = mutableStateListOf<Gift>()
    val stock = mutableStateMapOf<String, Int>().apply { gifts.forEach { g -> g.limit?.let { put(g.name, it) } } }
    val enabled = mutableStateListOf<String>()
    val chats = listOf(
        Chat("Избранное", "⭐", "Здесь твои заметки"),
        Chat("Анна", "👩", "Привет! Как дела?"),
        Chat("Канал Новости", "📢", "Вышло обновление Nova 0.1"),
        Chat("Dev-чат", "💻", "Кто пишет плагины?")
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NovaApp() }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val dark = LocalDark.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier.clip(shape)
            .background(if (dark) Color.White.copy(0.08f) else Color.White.copy(0.6f))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.5f), Color.White.copy(0.05f))), shape),
        content = content
    )
}

@Composable
fun NovaApp() {
    val s = remember { AppState() }
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Chat?>(null) }
    val scheme = if (s.dark) darkColorScheme(primary = Accent, background = Color(0xFF0E1621), surface = Color(0xFF17212B))
    else lightColorScheme(primary = Accent, background = Color(0xFFEFF3F7), surface = Color.White)
    val bg = if (s.dark) listOf(Color(0xFF0E1621), Color(0xFF1B2A3D)) else listOf(Color(0xFFEFF3F7), Color(0xFFD6E8F7))
    BackHandler(open != null) { open = null }
    CompositionLocalProvider(LocalDark provides s.dark) {
        MaterialTheme(colorScheme = scheme) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(bg))) {
                AnimatedContent(open, transitionSpec = {
                    (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 3 } + fadeOut())
                }, label = "nav") { chat ->
                    if (chat != null) ChatScreen(s, chat) { open = null }
                    else Scaffold(
                        containerColor = Color.Transparent,
                        bottomBar = {
                            NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(0.8f)) {
                                listOf("💬 Чаты", "👤 Профиль", "🎁 Магазин").forEachIndexed { i, t ->
                                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                                        icon = { Text(t.substringBefore(' '), fontSize = 20.sp) },
                                        label = { Text(t.substringAfter(' ')) })
                                }
                            }
                        }
                    ) { pad ->
                        Box(Modifier.padding(pad).statusBarsPadding()) {
                            when (tab) {
                                0 -> ChatList(s) { open = it }
                                1 -> ProfileScreen(s)
                                else -> ShopScreen(s)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatList(s: AppState, onOpen: (Chat) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Nova", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp)) }
        items(s.chats) { c ->
            Glass(Modifier.fillMaxWidth().clickable { onOpen(c) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Accent.copy(0.3f)), contentAlignment = Alignment.Center) { Text(c.emoji, fontSize = 24.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(c.name, fontWeight = FontWeight.SemiBold)
                        Text(c.msgs.last().text, maxLines = 1, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
                    }
                }
            }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { v = true }
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
        AnimatedVisibility(v, enter = fadeIn() + scaleIn(initialScale = 0.7f) + slideInVertically { it / 2 }) {
            Box(
                Modifier.clip(RoundedCornerShape(18.dp))
                    .background(if (m.mine) Accent else MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) { Text(m.text, color = if (m.mine) Color.White else MaterialTheme.colorScheme.onSurface) }
        }
    }
}

@Composable
fun ChatScreen(s: AppState, chat: Chat, onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    LaunchedEffect(chat.msgs.size) { list.animateScrollToItem(chat.msgs.size - 1) }
    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
        Glass(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onBack) { Text("←", fontSize = 22.sp) }
                Text(chat.emoji, fontSize = 22.sp); Spacer(Modifier.width(8.dp))
                Text(chat.name, fontWeight = FontWeight.SemiBold)
            }
        }
        LazyColumn(Modifier.weight(1f), state = list, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(chat.msgs) { Bubble(it) }
        }
        Glass(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Сообщение") },
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                Button(onClick = {
                    if (input.isNotBlank()) {
                        var t = input.trim()
                        plugins.filter { it.name in s.enabled }.forEach { t = it.fn(t) }
                        chat.msgs.add(Msg(t, true)); input = ""; s.coins += 1
                        scope.launch { delay(800); chat.msgs.add(Msg("Получено 👍", false)) }
                    }
                }) { Text("➤") }
            }
        }
    }
}

@Composable
fun ColorRow(selected: Int, count: Int, onPick: (Int) -> Unit, draw: (Int) -> Brush) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 6.dp)) {
        repeat(count) { i ->
            Box(Modifier.size(36.dp).clip(CircleShape).background(draw(i))
                .border(if (i == selected) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                .clickable { onPick(i) })
        }
    }
}

@Composable
fun ProfileScreen(s: AppState) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
        Box(Modifier.fillMaxWidth().height(190.dp)) {
            Box(Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(24.dp)).background(banners[s.banner]))
            Box(Modifier.align(Alignment.BottomStart).padding(start = 20.dp).size(96.dp)
                .border(4.dp, frames[s.frame], CircleShape).padding(6.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) { Text("😎", fontSize = 44.sp) }
        }
        Text(s.nick, color = s.nickColor, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(s.bio, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
        Text("🪙 ${s.coins}", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 6.dp))
        if (s.myGifts.isNotEmpty()) Text("Подарки: " + s.myGifts.joinToString(" ") { it.emoji }, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                OutlinedTextField(s.nick, { s.nick = it }, label = { Text("Ник") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(s.bio, { s.bio = it }, label = { Text("Описание") }, modifier = Modifier.fillMaxWidth())
                Text("Цвет ника"); ColorRow(palette.indexOf(s.nickColor), palette.size, { s.nickColor = palette[it] }) { Brush.linearGradient(listOf(palette[it], palette[it])) }
                Text("Рамка аватарки"); ColorRow(s.frame, frames.size, { s.frame = it }) { frames[it] }
                Text("Баннер"); ColorRow(s.banner, banners.size, { s.banner = it }) { banners[it] }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Тёмная тема", Modifier.weight(1f)); Switch(s.dark, { s.dark = it })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Плагины", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        plugins.forEach { p ->
            Glass(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(p.name, fontWeight = FontWeight.SemiBold); Text(p.desc, fontSize = 12.sp) }
                    Switch(p.name in s.enabled, { if (it) s.enabled.add(p.name) else s.enabled.remove(p.name) })
                }
            }
        }
    }
}

@Composable
fun ShopScreen(s: AppState) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Магазин подарков  🪙 ${s.coins}", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp)) }
        items(gifts) { g ->
            val left = s.stock[g.name]
            val can = s.coins >= g.price && (left == null || left > 0)
            Glass(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(g.emoji, fontSize = 36.sp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(g.name, fontWeight = FontWeight.SemiBold)
                        if (left != null) Text("Лимит: осталось $left", fontSize = 12.sp, color = Color(0xFFFFB300))
                    }
                    Button(enabled = can, onClick = {
                        s.coins -= g.price; s.myGifts.add(g)
                        if (left != null) s.stock[g.name] = left - 1
                    }) { Text("🪙 ${g.price}") }
                }
            }
        }
    }
}
